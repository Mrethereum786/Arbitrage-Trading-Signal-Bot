import requests
from utils.config import apiKey

def make_api_call_for_token_stats(contactAddress):
    return requests.get("https://api.arbiscan.io/api?module=stats&action=tokensupply&contractaddress={contactAddress}&apikey={apiKey}".format(contactAddress=contactAddress,apiKey=apiKey)).json()