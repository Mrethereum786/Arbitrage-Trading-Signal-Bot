import sqlite3
from datetime import datetime, timedelta
from utils.config import database_name

def create_tables():
    conn = sqlite3.connect(database_name)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transaction_data (
        id INTEGER PRIMARY KEY,
        blockNumber TEXT,
        timeStamp TEXT,
        hash TEXT UNIQUE,
        nonce TEXT,
        blockHash TEXT,
        fromAddress TEXT,
        contractAddress TEXT,
        toAddress TEXT,
        value TEXT,
        tokenName TEXT,
        tokenSymbol TEXT,
        tokenDecimal TEXT,
        transactionIndex TEXT,
        gas TEXT,
        gasPrice TEXT,
        gasUsed TEXT,
        cumulativeGasUsed TEXT,
        input TEXT,
        confirmations TEXT,
        tokenSupply TEXT
    );
    ''')


def insert_data(data):
    try:
        conn = sqlite3.connect(database_name)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO transaction_data (
                blockNumber, timeStamp, hash, nonce, blockHash,
                fromAddress, contractAddress, toAddress, value,
                tokenName, tokenSymbol, tokenDecimal, transactionIndex,
                gas, gasPrice, gasUsed, cumulativeGasUsed, input,
                confirmations, tokenSupply
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['blockNumber'], data['timeStamp'], data['hash'], data['nonce'], data['blockHash'],
            data['from'], data['contractAddress'], data['to'], data['value'],
            data['tokenName'], data['tokenSymbol'], data['tokenDecimal'], data['transactionIndex'],
            data['gas'], data['gasPrice'], data['gasUsed'], data['cumulativeGasUsed'], data['input'],
            data['confirmations'], data['TokenSupply']
        ))

        conn.commit()
        conn.close()
        return True
    except:
        return False
    finally:
        conn.close()
def create_tables():
    try:
        conn = sqlite3.connect(database_name)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transaction_data (
            id INTEGER PRIMARY KEY,
            blockNumber TEXT,
            timeStamp TEXT,
            hash TEXT UNIQUE,
            nonce TEXT,
            blockHash TEXT,
            fromAddress TEXT,
            contractAddress TEXT,
            toAddress TEXT,
            value TEXT,
            tokenName TEXT,
            tokenSymbol TEXT,
            tokenDecimal TEXT,
            transactionIndex TEXT,
            gas TEXT,
            gasPrice TEXT,
            gasUsed TEXT,
            cumulativeGasUsed TEXT,
            input TEXT,
            confirmations TEXT,
            tokenSupply TEXT
            );
            ''')
        return True
    except:
        return False
    finally:
            conn.close()
def get_max_block_number():
    try:

        conn = sqlite3.connect(database_name)
        cursor = conn.cursor()

        cursor.execute('SELECT blockNumber FROM transaction_data ORDER BY id DESC LIMIT 1')

        max_blockNumber = cursor.fetchone()[0]
        return max_blockNumber
    
    except :
        return None
    finally:
        conn.close()
def get_token_info(token_symbol):
    try:
        conn = sqlite3.connect(database_name)
        cursor = conn.cursor()

        twenty_four_hours_ago = int((datetime.now() - timedelta(hours=24)).timestamp())

        cursor.execute('''
            SELECT
                tokenName,
                tokenSymbol,
                tokenSupply,
                tokenDecimal,
                SUM(ROUND(value,10)) AS totalBurn,
                (SELECT SUM(ROUND(value,10)) FROM transaction_data WHERE tokenName = ? AND timeStamp >= ?) AS burn24h,
                (SUM(ROUND(value,10)) * 100.0 / tokenSupply) AS burnPercentage
            FROM
                transaction_data
            WHERE
                tokenSymbol = ?
        ''', (token_symbol, twenty_four_hours_ago, token_symbol))

        result = cursor.fetchone()
        return result

    except:
        return None

    finally:
        conn.close()