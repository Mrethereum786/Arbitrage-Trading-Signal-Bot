import requests
import json
import time

def send_to_telegram(messages):
    apiToken = '6637594476:AAHpxiwCBjCQxgCckjXzedyIMGfxEBPYcgU'
    chatID = '395495303'
    apiURL = f'https://api.telegram.org/bot{apiToken}/sendMessage'
    for messageouter in messages:

        
        def message_sender_internal(message):
            try:
                response = requests.post(apiURL, json={'chat_id': chatID, 'text': message})
                time.sleep(0.5)
            except Exception as e:
                time.sleep(0.5)
                message_sender_internal(message)
        message_sender_internal(messageouter)
