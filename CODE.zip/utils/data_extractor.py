import requests
from utils.config import apiKey,address

def make_api_call(max_block):
    return requests.get("https://api.arbiscan.io/api?module=account&action=tokentx&address={address}&startblock={max_block}&endblock=99999999999999999999&page=1&offset=10000&sort=desc&apikey={apiKey}".format(address=address,max_block=max_block,apiKey=apiKey)).json()