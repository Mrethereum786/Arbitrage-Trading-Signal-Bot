import threading
from utils.data_extractor import make_api_call
from utils.data_extractor_for_token import make_api_call_for_token_stats
from utils.bot_manager import send_to_telegram
import time
from utils.db_operations import create_tables, insert_data, get_max_block_number, get_token_info

print("STARTUP: ARBISCAN DEAD TRANSACTIONS TRACKER")

print("Information: Initializing and Syncronizing Database...")
create_tables()

sleep_time_in_minutes = 1
all_tokens_supply = {}

isdatabaseinit = True

def find_new_activities(latest_fetched_activities):
        global all_tokens_supply
        global isdatabaseinit
        try:
            new_data = []
            if(len(latest_fetched_activities) > 0):
                print(f"Action: Processing {len(latest_fetched_activities)} New Transactions")
            for activity in latest_fetched_activities:
                try:                       
                    tokenStats = all_tokens_supply[activity["tokenSymbol"]]  
                except KeyError:
                    tokenStats = make_api_call_for_token_stats(activity["contractAddress"])["result"]
                    #time.sleep(0.3)
                    all_tokens_supply[activity["tokenSymbol"]] = tokenStats
                activity["TokenSupply"] = tokenStats
                if(insert_data(activity)):
                    token = get_token_info(activity["tokenSymbol"])
                    message = '''{burnedNow} {tokenSymbol} BURNED!🔥

💰Total Burned:
{totalBurned} {tokenSymbol} (%{burnedPercentage})
🐦Tweet this burn!


Token Statistics:

Token: {tokenName}
SYMBOL: {tokenSymbol}
Total Supply: {totalSupply}
Decimals: {decimals}

Total Burned (24h): {burned24h}
Total Burned (All time): {totalBurned}


TX | Chart | Maestro | Statistics

Powered by $MOETA'''.format(burnedNow=activity["value"],tokenSymbol = token[1],totalBurned = token[4], burnedPercentage = token[6],tokenName=token[0],totalSupply=token[2], decimals=token[3], burned24h = token[5])
                    new_data.append(message)
            if (isdatabaseinit):
                isdatabaseinit = False
                print("Information: Database Initilization and Syncronization Finished. Now You will receive any future transctions.")
            else: 
                print("Information: Found "+str(len(new_data))+" New Transactions")
                if(len(new_data) > 0):
                    print('Action: Sending New Transactions.')
                    threading.Thread(target =send_to_telegram,args= [new_data],daemon=True).start()
                    print("Information: Messasges Handedover to Bot Manager.")
            print("Wait: Waiting For "+str(sleep_time_in_minutes)+" Minute(s) to Loop Again")

        except Exception as e:
            print("Exception: Something went wrong, retrying "+str(sleep_time_in_minutes)+" in minutes...")

while True:
    try:
        print('Action: Fetching Transactions')
        max_block = get_max_block_number()
        if max_block is None:
            max_block = 0
        activities = make_api_call(int(max_block)+1)['result']
        print('Action: Transactions Fetched Successfully')
        print('Action: Filtering New Transactions')
        find_new_activities(activities)
    except Exception as e:
        print("Exception: Something went wrong, retrying in "+str(sleep_time_in_minutes)+" minutes...")
    time.sleep(60*sleep_time_in_minutes)